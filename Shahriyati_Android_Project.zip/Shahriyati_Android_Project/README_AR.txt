شهريتي 2.0 – مشروع Android Studio

مهم: هذه ملفات مشروع Android Studio المصدرية وليست ملف APK جاهزاً.
لم يتم تجميع APK في بيئة الإنشاء الحالية لعدم توفر Android SDK وGradle.

طريقة إنشاء APK:
1) افتح Android Studio على الكمبيوتر.
2) اختر Open وافتح مجلد Shahriyati_Android_Project.
3) انتظر Gradle Sync، وثبّت Android SDK Platform 35 إذا طلبه البرنامج.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) سيظهر ملف APK داخل app/build/outputs/apk/debug/.

التطبيق يفتح نسخة الويب المضمنة محلياً داخل WebView. يدعم JavaScript وLocalStorage
واختيار صورة الشخص من الجهاز. البيانات محلية على نفس الهاتف؛ خذ نسخة احتياطية دورياً.
