import 'package:flutter/material.dart';

void main() => runApp(const NessijApp());

const orange = Color(0xFFFF7900);
const ink = Color(0xFF20252B);
const cream = Color(0xFFFFF8F1);

class NessijApp extends StatelessWidget {
  const NessijApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Nessij DZ',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: orange),
        scaffoldBackgroundColor: const Color(0xFFF8F8F8),
        fontFamily: 'Arial',
      ),
      home: const HomePage(),
    );
  }
}

class Category {
  final String title;
  final String subtitle;
  final IconData icon;
  const Category(this.title, this.subtitle, this.icon);
}

const categories = [
  Category('الأقمشة والمواد الأولية', 'أقمشة بالجملة ومخزون الورشات', Icons.layers_outlined),
  Category('الورشات والتصنيع', 'خياطة وتصنيع حسب الطلب', Icons.factory_outlined),
  Category('مستلزمات الخياطة', 'خيوط وأزرار وسحابات وإبر', Icons.content_cut),
  Category('الطباعة والسيروغرافيا', 'طباعة وتطريز وتخصيص', Icons.print_outlined),
  Category('الآلات والمعدات', 'آلات جديدة ومستعملة', Icons.precision_manufacturing_outlined),
  Category('الاستيراد VIP', 'توريد وخدمات استيراد', Icons.local_shipping_outlined),
  Category('المنتجات المحلية', 'منتجات جزائرية بالجملة', Icons.checkroom_outlined),
  Category('العروض والتخفيضات', 'عروض الموردين والصفقات', Icons.local_offer_outlined),
  Category('دليل الخدمات', 'تصميم وباترون وجودة وصيانة', Icons.handyman_outlined),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int selectedTab = 0;
  String search = '';

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.white,
          title: Row(children: [
            Container(
              width: 42, height: 42,
              decoration: BoxDecoration(color: orange, borderRadius: BorderRadius.circular(13)),
              child: const Icon(Icons.cut, color: Colors.white, size: 25),
            ),
            const SizedBox(width: 10),
            const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Nessij DZ', style: TextStyle(fontWeight: FontWeight.w900, color: ink, fontSize: 19)),
              Text('نسيج الجزائر', style: TextStyle(fontSize: 11, color: Colors.black54)),
            ]),
          ]),
          actions: [
            IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none_rounded, color: ink)),
            const SizedBox(width: 4),
          ],
        ),
        body: IndexedStack(
          index: selectedTab,
          children: [
            _homeContent(),
            _simplePage('طلباتي', Icons.receipt_long_outlined, 'ستظهر هنا طلبات عروض الأسعار والتواصل مع الموردين.'),
            _simplePage('المفضلة', Icons.favorite_border, 'احفظ الموردين والمنتجات التي تهمك هنا.'),
            _simplePage('حسابي', Icons.person_outline, 'سجّل الدخول لإدارة حسابك كمشتري أو مورد.'),
          ],
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: selectedTab,
          onDestinationSelected: (v) => setState(() => selectedTab = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.request_quote_outlined), label: 'طلباتي'),
            NavigationDestination(icon: Icon(Icons.favorite_border), label: 'المفضلة'),
            NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
          ],
        ),
      ),
    );
  }

  Widget _homeContent() {
    final shown = categories.where((c) => c.title.contains(search) || c.subtitle.contains(search)).toList();
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFFFF8A24), Color(0xFFE85F00)]),
            borderRadius: BorderRadius.circular(22),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('كل احتياجات النسيج والخياطة في مكان واحد', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('اكتشف الموردين والورشات والمنتجات المحلية في الجزائر', style: TextStyle(color: Colors.white, height: 1.5)),
            const SizedBox(height: 14),
            OutlinedButton(
              style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white)),
              onPressed: () {},
              child: const Text('اكتشف المنصة'),
            )
          ]),
        ),
        const SizedBox(height: 16),
        TextField(
          textDirection: TextDirection.rtl,
          onChanged: (v) => setState(() => search = v),
          decoration: InputDecoration(
            hintText: 'ابحث عن قماش، ورشة، مورد أو خدمة...',
            prefixIcon: const Icon(Icons.search),
            filled: true, fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
          ),
        ),
        const SizedBox(height: 20),
        _sectionTitle('تصفح الأقسام', 'عرض الكل'),
        const SizedBox(height: 10),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: shown.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3, crossAxisSpacing: 9, mainAxisSpacing: 9, childAspectRatio: .86,
          ),
          itemBuilder: (context, i) {
            final c = shown[i];
            return InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CategoryPage(category: c))),
              child: Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFEEEEEE))),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Container(width: 43, height: 43, decoration: BoxDecoration(color: cream, borderRadius: BorderRadius.circular(13)), child: Icon(c.icon, color: orange, size: 24)),
                  const SizedBox(height: 8),
                  Text(c.title, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold, color: ink)),
                ]),
              ),
            );
          },
        ),
        const SizedBox(height: 20),
        _sectionTitle('عروض مميزة', 'عرض المزيد'),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(color: const Color(0xFFFFF0E3), borderRadius: BorderRadius.circular(17)),
          child: const Row(children: [
            Icon(Icons.local_offer_rounded, color: orange, size: 34),
            SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('اكتشف عروض الموردين', style: TextStyle(fontWeight: FontWeight.bold, color: ink)),
              Text('تخفيضات ومنتجات جديدة — للعرض والتواصل فقط', style: TextStyle(fontSize: 11, color: Colors.black54)),
            ])),
            Icon(Icons.arrow_back_ios_new, size: 15, color: orange),
          ]),
        ),
        const SizedBox(height: 20),
        _sectionTitle('خدمات مهنية', 'اكتشف الخدمات'),
        const SizedBox(height: 10),
        const Row(children: [
          Expanded(child: ServiceTile(icon: Icons.design_services_outlined, title: 'تصميم وباترون')),
          SizedBox(width: 9),
          Expanded(child: ServiceTile(icon: Icons.verified_outlined, title: 'مراقبة الجودة')),
          SizedBox(width: 9),
          Expanded(child: ServiceTile(icon: Icons.build_outlined, title: 'صيانة المعدات')),
        ]),
        const SizedBox(height: 20),
        _sectionTitle('ابدأ بالتعامل التجاري', ''),
        const SizedBox(height: 8),
        const Text('ابحث عن مورد، اكتشف ورشة متخصصة، أو أرسل طلب عرض سعر من خلال Nessij DZ.', style: TextStyle(color: Colors.black54, height: 1.6)),
      ],
    );
  }

  Widget _sectionTitle(String title, String action) => Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: ink)),
      if (action.isNotEmpty) Text(action, style: const TextStyle(color: orange, fontSize: 12, fontWeight: FontWeight.bold)),
    ],
  );

  Widget _simplePage(String title, IconData icon, String message) => Center(
    child: Padding(
      padding: const EdgeInsets.all(28),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, size: 58, color: orange),
        const SizedBox(height: 14),
        Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(message, textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54, height: 1.5)),
      ]),
    ),
  );
}

class ServiceTile extends StatelessWidget {
  final IconData icon;
  final String title;
  const ServiceTile({super.key, required this.icon, required this.title});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 5),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
    child: Column(children: [
      Icon(icon, color: orange, size: 25),
      const SizedBox(height: 7),
      Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold)),
    ]),
  );
}

class CategoryPage extends StatelessWidget {
  final Category category;
  const CategoryPage({super.key, required this.category});
  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: Text(category.title)),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(category.icon, color: orange, size: 64),
            const SizedBox(height: 16),
            Text(category.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(category.subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 20),
            const Text('سيتم ربط هذا القسم بالمنتجات والموردين عند إعداد قاعدة البيانات.', textAlign: TextAlign.center, style: TextStyle(height: 1.5)),
          ]),
        ),
      ),
    ),
  );
}
