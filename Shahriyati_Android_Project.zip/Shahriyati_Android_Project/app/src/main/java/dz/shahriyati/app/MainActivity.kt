package dz.shahriyati.app

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val fileRequestCode = 701
    private val notificationRequestCode = 702
    private val prefs by lazy { getSharedPreferences("shahriyati_secure", Context.MODE_PRIVATE) }
    private val channelId = "shahriyati_reminders"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
        webView.addJavascriptInterface(NativeBridge(), "ShahriyatiNative")
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                webView.evaluateJavascript("window.onNativeReady && window.onNativeReady(${isBiometricEnabled()});", null)
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.scheme == "tel" || uri.scheme == "https" || uri.scheme == "mailto") {
                    try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) {}
                    return true
                }
                return false
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(webView: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val intent = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                return try { startActivityForResult(intent, fileRequestCode); true }
                catch (_: Exception) { fileCallback = null; Toast.makeText(this@MainActivity, "تعذر فتح معرض الصور", Toast.LENGTH_SHORT).show(); false }
            }
        }
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun isBiometricEnabled() = prefs.getBoolean("biometric_enabled", false)

    private fun biometricPrompt(onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        val manager = BiometricManager.from(this)
        val status = manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
        if (status != BiometricManager.BIOMETRIC_SUCCESS) {
            onFailure("هذا الهاتف لا يدعم البصمة أو قفل الجهاز المتوافق")
            return
        }
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onSuccess() }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { onFailure(errString.toString()) }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("حماية شهريتي")
            .setSubtitle("أكد هويتك لفتح بياناتك المالية")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
            .build()
        prompt.authenticate(info)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "تذكيرات شهريتي", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "تذكيرات مواعيد الديون والنصائح المالية"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun postNotification(title: String, body: String) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
    }

    inner class NativeBridge {
        @JavascriptInterface fun isBiometricEnabled(): Boolean = this@MainActivity.isBiometricEnabled()
        @JavascriptInterface fun authenticate() {
            runOnUiThread {
                biometricPrompt(
                    onSuccess = { webView.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(true);", null) },
                    onFailure = { webView.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(false, ${org.json.JSONObject.quote(it)});", null) }
                )
            }
        }
        @JavascriptInterface fun enableBiometric() {
            runOnUiThread {
                biometricPrompt(
                    onSuccess = {
                        prefs.edit().putBoolean("biometric_enabled", true).apply()
                        webView.evaluateJavascript("window.onBiometricSetup && window.onBiometricSetup(true, 'تم تفعيل الحماية بالبصمة');", null)
                    },
                    onFailure = { webView.evaluateJavascript("window.onBiometricSetup && window.onBiometricSetup(false, ${org.json.JSONObject.quote(it)});", null) }
                )
            }
        }
        @JavascriptInterface fun disableBiometric() {
            prefs.edit().putBoolean("biometric_enabled", false).apply()
            runOnUiThread { webView.evaluateJavascript("window.onBiometricSetup && window.onBiometricSetup(true, 'تم إيقاف قفل البصمة');", null) }
        }
        @JavascriptInterface fun requestNotifications() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    this@MainActivity.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), notificationRequestCode)
                } else {
                    webView.evaluateJavascript("window.onNotificationPermission && window.onNotificationPermission(true);", null)
                }
            }
        }
        @JavascriptInterface fun notifyUser(title: String, body: String) {
            runOnUiThread { postNotification(title.take(80), body.take(300)) }
        }
        @JavascriptInterface fun scheduleDebtReminder(id: Int, name: String, dueDate: String, amount: String) {
            try {
                val parts = dueDate.split("-")
                if (parts.size != 3) return
                val calendar = java.util.Calendar.getInstance().apply {
                    set(parts[0].toInt(), parts[1].toInt() - 1, parts[2].toInt(), 9, 0, 0)
                    set(java.util.Calendar.MILLISECOND, 0)
                }
                if (calendar.timeInMillis <= System.currentTimeMillis()) calendar.timeInMillis = System.currentTimeMillis() + 60_000
                val intent = Intent(this@MainActivity, DebtReminderReceiver::class.java).apply {
                    putExtra("title", "شهريتي: موعد تسديد")
                    putExtra("body", "$name · $amount دج")
                }
                val pending = android.app.PendingIntent.getBroadcast(this@MainActivity, id, intent,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
                val alarm = getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
                alarm.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pending)
            } catch (_: Exception) { }
        }
        @JavascriptInterface fun cancelDebtReminder(id: Int) {
            val intent = Intent(this@MainActivity, DebtReminderReceiver::class.java)
            val pending = android.app.PendingIntent.getBroadcast(this@MainActivity, id, intent,
                android.app.PendingIntent.FLAG_NO_CREATE or android.app.PendingIntent.FLAG_IMMUTABLE)
            if (pending != null) {
                (getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager).cancel(pending)
                pending.cancel()
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == notificationRequestCode) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            webView.evaluateJavascript("window.onNotificationPermission && window.onNotificationPermission($granted);", null)
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileRequestCode) {
            val result = if (resultCode == Activity.RESULT_OK && data != null) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
            fileCallback?.onReceiveValue(result)
            fileCallback = null
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}

class DebtReminderReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val channelId = "shahriyati_reminders"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(channelId, "تذكيرات شهريتي", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(intent.getStringExtra("title") ?: "شهريتي: تذكير")
            .setContentText(intent.getStringExtra("body") ?: "لديك موعد تسديد اليوم")
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        context.getSystemService(NotificationManager::class.java).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
    }
}
